﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCC_API {
    internal class CAudio {
        public static CAudioSettings Settings;

        public const string SettingsFilename = "VCC_API.json";

        public static void LoadFromFile(string fn) {
            using (var rfs = new System.IO.StreamReader(fn)) {
                var json = rfs.ReadToEnd();
                Console.WriteLine("Load settings from file. [" + fn + "]");
                Console.WriteLine(json);
                Settings = System.Text.Json.JsonSerializer.Deserialize<CAudioSettings>(json);
            }
        }

        public static void SaveToFile(string fn) {
            using (var wfs = new System.IO.StreamWriter(fn)) {
                var json = System.Text.Json.JsonSerializer.Serialize(Settings, new System.Text.Json.JsonSerializerOptions() { WriteIndented = true });
                Console.WriteLine("Save settings to file. [" + fn + "]");
                Console.WriteLine(json);
                wfs.WriteLine(json);
            }
        }

        public static CAudioIn AudioIn;
        public static CAudioConvert AudioConvert;
        public static CAudioOut AudioOut;

        public static void Start(bool AutoStart) {
            AudioIn = new CAudioIn();
            AudioConvert = new CAudioConvert();
            AudioOut = new CAudioOut();

            if (AutoStart) {
                AudioIn.Start();
            }
        }

        public static void Stop() {
            // 終了処理は雑
            AudioIn.Stop();
        }

        public class CAudioBlock {
            public DateTime SampleHeadDT;
            public DateTime StartConvertDT;
            public float[] Samples;
            public int SourceSamplesCount;
            public Stopwatch Stopwatch = null;
            public CAudioBlock(DateTime _SampleHeadDT,DateTime _StartConvertDT, float[] _Samples) {
                SampleHeadDT = _SampleHeadDT;
                StartConvertDT = _StartConvertDT;
                Samples = _Samples;
                SourceSamplesCount = Samples.Length;
            }
        }

        public class CRateStatus {
            private float _InPeakLevel;
            public float InPeakLevel {
                get { lock (this) { var res = _InPeakLevel; _InPeakLevel = 0; return res; } }
                set { lock (this) { if (_InPeakLevel < value) { _InPeakLevel = value; } } }
            }

            private float _OutPeakLevel;
            public float OutPeakLevel {
                get { lock (this) { var res = _OutPeakLevel; _OutPeakLevel = 0; return res; } }
                set { lock (this) { if (_OutPeakLevel < value) { _OutPeakLevel = value; } } }
            }

            private TimeSpan _AudioIn, _AudioConvert, _AudioOut;
            public TimeSpan AudioIn {
                get { lock (this) { var res = _AudioIn; _AudioIn = TimeSpan.Zero; return res; } }
                set { lock (this) { if (_AudioIn < value) { _AudioIn = value; } } }
            }
            public TimeSpan AudioConvert {
                get { lock (this) { var res = _AudioConvert; _AudioConvert = TimeSpan.Zero; return res; } }
                set { lock (this) { if (_AudioConvert < value) { _AudioConvert = value; } } }
            }
            public TimeSpan AudioOut {
                get { lock (this) { var res = _AudioOut; _AudioOut = TimeSpan.Zero; return res; } }
                set { lock (this) { if (_AudioOut < value) { _AudioOut = value; } } }
            }

            private TimeSpan RateMin, RateMax;
            private TimeSpan RateStackValue;
            private int RateStackCount;
            public void SetRate(TimeSpan Rate) {
                lock (this) {
                    if (RateMin == System.TimeSpan.Zero) { RateMin = Rate; }
                    if (Rate < RateMin) { RateMin = Rate; }
                    if (RateMax == System.TimeSpan.Zero) { RateMax = Rate; }
                    if (RateMax < Rate) { RateMax = Rate; }
                    RateStackValue += Rate;
                    RateStackCount++;
                }
            }
            public class CRateRes {
                public TimeSpan Min, Max, Avg;
            }
            public CRateRes GetRate() {
                var res = new CRateRes();
                lock (this) {
                    res.Min = RateMin; RateMin = TimeSpan.Zero;
                    res.Max = RateMax; RateMax = TimeSpan.Zero;
                    if (RateStackCount == 0) {
                        res.Avg = TimeSpan.Zero;
                    } else {
                        res.Avg = RateStackValue / RateStackCount;
                    }
                    RateStackValue = TimeSpan.Zero;
                    RateStackCount = 0;
                }
                return res;
            }
        }
        public static CRateStatus RateStatus = new CRateStatus();
    }
}
