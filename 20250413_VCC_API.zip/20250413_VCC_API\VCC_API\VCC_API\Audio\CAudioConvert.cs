﻿using NAudio.CoreAudioApi;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static VCC_API.CAudio;

namespace VCC_API {
    internal class CAudioConvert {
        public CVCC_RestAPI VCC_RestAPI;
        private CVCC_SocketIO VCC_SocketIO = null;

        public CAudioConvert() {
            VCC_RestAPI = new CVCC_RestAPI(CAudio.Settings.VCC.Addr, CAudio.Settings.VCC.Port, CAudio.Settings.AudioIn.SampleRate, CAudio.Settings.AudioOut.SampleRate);

            switch (CAudio.Settings.VCC.GetProtocol()) {
                case CAudioSettings.CVCC.EProtocol.sio:
                    VCC_SocketIO = new CVCC_SocketIO(CAudio.Settings.VCC.Addr, CAudio.Settings.VCC.Port);
                    VCC_SocketIO.Connect();
                    break;
                default: throw new Exception("CAudioConvert: Unknown VCC protocol. " + CAudio.Settings.VCC.Protocol.ToString());
            }
        }

        public void ResetSampleRateTo48k() { VCC_RestAPI.ResetSampleRateTo48k(); }

        private System.DateTime StartDT;

        private List<CAudio.CAudioBlock> AudioBlocks = new List<CAudio.CAudioBlock>();
        public void AudioBlocks_Add(CAudio.CAudioBlock AudioBlock,bool PassThru) {
            if (PassThru) {
                for(var idx = 0; idx < AudioBlock.Samples.Length; idx++) {
                    AudioBlock.Samples[idx] *= 0.5f;
                }
                CAudio.AudioOut.SendSamples(AudioBlock);
                return;
            }

            lock (AudioBlocks) {
                var BlocksLimit = CAudio.Settings.AudioIn.isBeatriceV2 ? 4 : 2;
                if (BlocksLimit <= AudioBlocks.Count) {
                    Console.WriteLine(BlocksLimit + "個以上前のチャンクが残っていたのでスキップしました。 " + AudioBlocks.Count);
                    return;
                }

                var isReady = AudioBlocks.Count == 0;

                AudioBlocks.Add(AudioBlock);

                if (isReady) {
                    StartDT = DateTime.Now;
                    if (!VCC_SocketIO.StartConvert(AudioBlocks[0].Samples)) { AudioBlocks.Clear(); }
                }
            }
        }

        public void AudioBlocks_CompleteCallback(byte[] RecvBuf) {
            CAudioBlock CurBlock;

            lock (AudioBlocks) {
                var elp = System.DateTime.Now - StartDT;
                if ((CAudio.Settings.AudioIn.GetChunkTS() + System.TimeSpan.FromSeconds(0.01)) < elp) { Console.WriteLine("変換時間オーバー elp=" + elp.ToString()); }
                CAudio.RateStatus.AudioConvert = elp;

                CurBlock = AudioBlocks[0];
                AudioBlocks.RemoveAt(0);

                if (1 <= AudioBlocks.Count) {
                    StartDT = DateTime.Now;
                    if (!VCC_SocketIO.StartConvert(AudioBlocks[0].Samples)) { AudioBlocks.Clear(); }
                }
            }

            var Samples = VCC_SocketIO.GetConvert(RecvBuf);
            if (Samples != null) {
                foreach (var Sample in Samples) {
                    CAudio.RateStatus.OutPeakLevel=System.Math.Abs( Sample);
                }
                if (CurBlock.SourceSamplesCount != Samples.Length) { Console.WriteLine("変換前と変換後のサイズが違います。 CurBlock.SourceSamplesCount=" + CurBlock.SourceSamplesCount + ", Samples.Length=" + Samples.Length); }
                CurBlock.Samples = Samples;
                CAudio.AudioOut.SendSamples(CurBlock);
            }
        }
    }
}
