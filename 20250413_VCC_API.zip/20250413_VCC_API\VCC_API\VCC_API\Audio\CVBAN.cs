﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace VCC_API {
    internal class CVBAN {
        [DllImport("winmm.dll", ExactSpelling = true, CharSet = CharSet.Ansi)]
        public static extern uint timeBeginPeriod(uint uPeriod);

        [DllImport("winmm.dll", ExactSpelling = true, CharSet = CharSet.Ansi)]
        public static extern uint timeEndPeriod(uint uPeriod);

        private System.Threading.Tasks.Task ThreadTask;

        private System.Net.Sockets.UdpClient udp;

        private const int MaxSamplesCount = 256;

        private int SampleRate;

        private const int Channels = 2;
        private const int Bits = 32;

        private byte[] buf = new byte[28 + (MaxSamplesCount * Channels * (Bits / 8))];

        public CVBAN(string Addr, int Port, int _SampleRate, string StreamName) {
            timeBeginPeriod(1);

            SampleRate = _SampleRate;

            udp = new System.Net.Sockets.UdpClient(Addr, Port);

            buf[0] = (byte)'V'; buf[1] = (byte)'B'; buf[2] = (byte)'A'; buf[3] = (byte)'N';

            switch (SampleRate) {
                case 6000: buf[4] = 0; break;
                case 48000: buf[4] = 3; break;
                default: throw new Exception();
            }

            buf[5] = (byte)0;

            if ((Channels <= 0) || (256 < Channels)) { throw new Exception(); }
            buf[6] = (byte)(Channels - 1);

            switch (Bits) {
                case 16: buf[7] = 1; break; // 16bits short
                case 32: buf[7] = 4; break; // 32bits float
                default: throw new Exception();
            }

            const byte VBAN_CODEC_PCM = 0x00;
            buf[7] |= VBAN_CODEC_PCM;

            for (var idx = 0; idx < 16; idx++) {
                if (idx < StreamName.Length) {
                    buf[8 + idx] = (byte)StreamName[idx];
                } else {
                    buf[8 + idx] = (byte)0;
                }
            }

            ThreadTask = System.Threading.Tasks.Task.Run(ThreadExec);
        }

        ~CVBAN() {
            timeEndPeriod(1);
        }

        private class CPacket {
            public DateTime SendDT;
            public float[] Samples;
            public float Volume;
            public CPacket(DateTime _SendDT, float[] _Samples, float _Volume) {
                SendDT = _SendDT;
                Samples = _Samples;
                Volume = _Volume;
            }
        }
        private List<CPacket> Packets = new List<CPacket>();

        public void ThreadExec() {
            while (true) {
                try {
                    while (true) {
                        CPacket Packet = null;
                        lock (Packets) {
                            if (1 <= Packets.Count) {
                                Packet = Packets[0];
                                Packets.RemoveAt(0);
                            }
                        }
                        if (Packet == null) {
                            System.Threading.Thread.Sleep(1);
                            continue;
                        }

                        var idx = 0;
                        var last = Packet.Samples.Length;
                        while (1 <= last) {
                            var size = last;
                            if (256 < size) { size = 256; }

                            while (System.DateTime.Now < Packet.SendDT) {
                                System.Threading.Thread.Sleep(1);
                            }
                            SendPacket(Packet.Samples, idx, size, Packet.Volume);

                            idx += size;
                            last -= size;

                            Packet.SendDT += TimeSpan.FromSeconds((double)size / SampleRate);
                        }
                    }
                } catch (Exception ex) { Console.WriteLine("CVBAN: Thread exception: " + ex.Message + "\n" + ex.StackTrace); Environment.Exit(1); }
            }
        }

        private int FrameCounter = 0;

        public void SendPacket(float[] Samples, int SamplesIndex, int SamplesCount, float Volume) {
            if (SamplesCount == 0) { return; }

            if ((SamplesCount <= 0) || (MaxSamplesCount < SamplesCount)) { throw new Exception(); }
            buf[5] = (byte)(SamplesCount - 1);

            Array.Copy(BitConverter.GetBytes(FrameCounter), 0, buf, 24, 4);
            FrameCounter++;

            var SampleSize = Bits / 8;
            var buflen = 28 + (SamplesCount * Channels * SampleSize);
            for (var idx = 0; idx < SamplesCount; idx++) {
                var bytes = BitConverter.GetBytes(Samples[SamplesIndex + idx] * Volume);
                Array.Copy(bytes, 0, buf, 28 + (((idx * Channels) + 0) * SampleSize), 4);
                Array.Copy(bytes, 0, buf, 28 + (((idx * Channels) + 1) * SampleSize), 4);
            }

            udp.Send(buf, buflen);
        }

        public void SendPacket(DateTime SendDT, float[] Samples, float Volume) {
            lock (Packets) {
                Packets.Add(new CPacket(SendDT, Samples, Volume));
            }
        }
    }
}
