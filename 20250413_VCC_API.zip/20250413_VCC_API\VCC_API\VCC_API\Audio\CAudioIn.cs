﻿using NAudio.SoundFont;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using static VCC_API.CAudio;

namespace VCC_API {
    internal class CAudioIn {
        private NAudio.CoreAudioApi.WasapiCapture WaveIn;

        public class CPassThru {
            private bool v;
            public void Set(bool _v) { lock (this) { v = _v; } }
            public bool Get() { lock (this) { return v; } }
        }
        public CPassThru PassThru = new CPassThru();

        public CAudioIn() {
            WaveIn = new NAudio.CoreAudioApi.WasapiCapture(CAudioIn_Helper.MMDevice_FindCapture(CAudio.Settings.AudioIn.DeviceName), true, 1);

            WaveIn.DataAvailable += WaveInOnDataAvailable;
            WaveIn.RecordingStopped += WaveInOnRecordingStopped;

            var wf = WaveIn.WaveFormat;
            Console.WriteLine("CAudioIn: WaveIn format. SampleRate:" + wf.SampleRate + ", bps:" + wf.BitsPerSample + ", chs:" + wf.Channels + ",");

            if ((wf.BitsPerSample != 32)) { throw new Exception("CAudioIn: 32bits以外は録音しない。 bps:" + WaveIn.WaveFormat.BitsPerSample); }

            if (wf.SampleRate != CAudio.Settings.AudioIn.SampleRate) { throw new Exception("CAudioIn: マイク入力周波数(" + wf.SampleRate + "Hz)と、VCC入力周波数(" + CAudio.Settings.AudioIn.SampleRate + "Hz)が違います。"); }
        }

        public void Start() {
            lock (this) {
                WaveIn.StartRecording();
            }
        }

        public void Stop() {
            lock (this) {
                WaveIn.StopRecording();
            }
        }

        private void WaveInOnRecordingStopped(object sender, NAudio.Wave.StoppedEventArgs e) {
            Console.WriteLine("CAudioIn: 録音ストリームが停止しました。");
        }

        private List<Single> WriteBuf = new List<Single>();

        private const int BeatriceV2_ChunkSize = 480; // BeatriceV2は480サンプル以外のブロックを受け付けない
        private int BlankTimeout = 0;

        private void WaveInOnDataAvailable(object sender, NAudio.Wave.WaveInEventArgs e) {
            try {
                var SampleRate = WaveIn.WaveFormat.SampleRate;
                var SampleLen = WaveIn.WaveFormat.BitsPerSample / 8;
                var Channels = WaveIn.WaveFormat.Channels;
                var SamplesCount = e.BytesRecorded / SampleLen / Channels;

                var ThresholdLevel = CAudio.Settings.AudioIn.ThresholdLevel;

                var smps = new float[SamplesCount];
                var PeakLevel = 0f;
                for (var idx = 0; idx < smps.Length; idx++) {
                    var smp = BitConverter.ToSingle(e.Buffer, ((idx * Channels) + 0) * SampleLen);// マルチチャネルは最初のサンプルしか取得しない
                    smps[idx] = smp * 1f;
                    var Level = System.Math.Abs(smps[idx]);
                    if (PeakLevel < Level) { PeakLevel = Level; }
                    CAudio.RateStatus.InPeakLevel = Level;
                    if (ThresholdLevel <= Level) {
                        if (CAudio.Settings.AudioIn.isBeatriceV2) {
                            BlankTimeout = (int)(CAudio.Settings.AudioIn.SampleRate * 0.1);  // 発話後0.1秒間は変換を継続する。無音を変換させると、直後の声が変換されないため。
                        } else {
                            BlankTimeout = CAudio.Settings.AudioIn.SampleRate * 3 * 60;  // 発話後3分間は変換を継続する。
                        }
                    }
                }

                lock (this) {
                    WriteBuf.AddRange(smps);
                    var ChunkSize = CAudio.Settings.AudioIn.GetChunkSize();
                    while (ChunkSize <= WriteBuf.Count) {
                        CAudio.RateStatus.AudioIn = System.TimeSpan.FromSeconds((double)WriteBuf.Count / CAudio.Settings.AudioIn.SampleRate);
                        var SampleHeadDT = System.DateTime.Now - System.TimeSpan.FromSeconds((double)WriteBuf.Count / CAudio.Settings.AudioIn.SampleRate);

                        var srcbuf = new float[ChunkSize];
                        for (var idx = 0; idx < srcbuf.Length; idx++) {
                            srcbuf[idx] = WriteBuf[idx];
                        }
                        WriteBuf.RemoveRange(0, srcbuf.Length);

                        CAudio.AudioConvert.AudioBlocks_Add(new CAudio.CAudioBlock(SampleHeadDT, System.DateTime.Now, srcbuf), (BlankTimeout < 0)|| PassThru.Get());

                        BlankTimeout -= srcbuf.Length;
                    }
                }
            } catch (Exception ex) { Console.WriteLine("CAudioIn: WaveInOnDataAvailable exception: " + ex.ToString()); Environment.Exit(1); }
        }
    }
}
