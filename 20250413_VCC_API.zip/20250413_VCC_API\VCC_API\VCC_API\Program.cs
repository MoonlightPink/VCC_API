﻿using System.Diagnostics;

namespace VCC_API {
    internal class Program {
        static void Main(string[] args) {
            try {
                Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.RealTime;

                Console.WriteLine("VCC_API.exe 2025/04/13");
                Console.WriteLine();

                Console.WriteLine("これは、ハードウェアインターフェースを使わずに、VCClient と Voice Meeter を使って、できるだけ低遅延でRVC変換するためのサポートアプリです。");
                Console.WriteLine();

                if (!System.IO.File.Exists(CAudio.SettingsFilename)) {
                    Console.WriteLine("設定ファイル [" + CAudio.SettingsFilename + "]が見つかりません。");
                    Console.WriteLine("VCC_API_Setup.exe で初期設定してください。");
                    return;
                }

                CAudio.Settings = new CAudioSettings();
                CAudio.LoadFromFile(CAudio.SettingsFilename);

                CAudio.Start(true);

                Console.WriteLine();
                Console.WriteLine("変換を開始しました。何かキーを押すと終了します。");
                Console.WriteLine("モデル関連の操作（使用中スロットの変更や編集など）は、当アプリを終了した状態で行ってください。");
                Console.WriteLine();

                var ReqExit = false;

                var HelpTimeout = System.DateTime.FromBinary(0);
                var LogTimeout = System.DateTime.FromBinary(0);

                while (!ReqExit) {
                    while (Console.KeyAvailable) {
                        var key = Console.ReadKey();
                        switch (key.Key) {
                            case ConsoleKey.Escape: ReqExit = true; break;
                            case ConsoleKey.H: CAudio.AudioOut.HeartBeat.SetEnable(!CAudio.AudioOut.HeartBeat.GetEnable()); break;
                            case ConsoleKey.P: CAudio.AudioIn.PassThru.Set(!CAudio.AudioIn.PassThru.Get()); break;
                            case ConsoleKey.M: CAudio.AudioOut.Volume.SetLevel((CAudio.AudioOut.Volume.GetLevel() == 1) ? 0.2f : 1f); break;
                        }
                    }
                    System.Threading.Thread.Sleep(100);

                    if (HelpTimeout < System.DateTime.Now) {
                        HelpTimeout = System.DateTime.Now + System.TimeSpan.FromSeconds(15);
                        Console.WriteLine("Key assign: H: Heart beat, P:Passthru, M: Mute.");
                    }

                    if (LogTimeout < System.DateTime.Now) {
                        LogTimeout = System.DateTime.Now + System.TimeSpan.FromSeconds(1);

                        if (CAudio.AudioIn.PassThru.Get()) { Console.WriteLine("!!!! PassThru !!!!"); }
                        if (CAudio.AudioOut.Volume.GetLevel() != 1) { Console.WriteLine("Current volume level: " + CAudio.AudioOut.Volume.GetLevel()); }

                        var RateIn = CAudio.RateStatus.AudioIn;
                        var RateConvert = CAudio.RateStatus.AudioConvert;
                        var RateOut = CAudio.RateStatus.AudioOut;
                        var Rate = CAudio.RateStatus.GetRate();
                        var InPeakLevel = CAudio.RateStatus.InPeakLevel;
                        var OutPeakLevel = CAudio.RateStatus.OutPeakLevel;
                        Console.WriteLine(System.DateTime.Now.TimeOfDay.ToString().Substring(0, 12) + " Chunk=" + CAudio.Settings.AudioIn.GetChunkTS().TotalMilliseconds.ToString("F0") + "ms, Rate: In=" + RateIn.TotalMilliseconds.ToString("F0") + "ms, Convert=" + RateConvert.TotalMilliseconds.ToString("F0") + "ms, Out=" + RateOut.TotalMilliseconds.ToString("F0") + "ms. (Min/Avg/Max:" + Rate.Min.TotalMilliseconds.ToString("F0") + "/" + Rate.Avg.TotalMilliseconds.ToString("F0") + "/" + Rate.Max.TotalMilliseconds.ToString("F0") + "ms) (Peak:" + InPeakLevel.ToString("F3") + " / " + OutPeakLevel.ToString("F3") + ")");
                        Console.Title = "VCC_API rate " + Rate.Avg.TotalMilliseconds.ToString("F0") + "ms";
                    }
                }

                Console.WriteLine("Terminate.");

                CAudio.Stop();

                CAudio.AudioConvert.ResetSampleRateTo48k();

            } catch (Exception ex) { Console.WriteLine("Main exception: " + ex.ToString()); Environment.Exit(1); }
        }
    }
}
