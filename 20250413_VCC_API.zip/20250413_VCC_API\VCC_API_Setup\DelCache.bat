chcp 65001
rmdir /s /q .vs
set appname=VCC_API_Setup
rmdir /s /q %appname%\bin
rmdir /s /q %appname%\obj
rmdir /s /q %appname%\publish
rmdir /s /q packages
pause
