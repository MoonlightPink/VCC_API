﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCC_API {
    internal class CAudioIn_Helper {
        public static NAudio.CoreAudioApi.MMDevice MMDevice_FindRender(string FriendlyName) {
            foreach (var Device in new NAudio.CoreAudioApi.MMDeviceEnumerator().EnumerateAudioEndPoints(NAudio.CoreAudioApi.DataFlow.Render, NAudio.CoreAudioApi.DeviceState.Active)) {
                if (Device.FriendlyName.Equals(FriendlyName)) {
                    Console.WriteLine("CAudioIn: Render device selected. [" + Device.FriendlyName + "]");
                    return Device;
                }
            }

            foreach (var Device in new NAudio.CoreAudioApi.MMDeviceEnumerator().EnumerateAudioEndPoints(NAudio.CoreAudioApi.DataFlow.Render, NAudio.CoreAudioApi.DeviceState.Active)) {
                Console.WriteLine(Device.ID + "\t" + Device.FriendlyName + "\t" + Device.DeviceFriendlyName + "\t" + Device.DataFlow.ToString());
            }

            throw new Exception("CAudioIn: 指定されたRenderデバイスがWASAPIで見つかりませんでした。 [" + FriendlyName + "]");
        }

        public static NAudio.CoreAudioApi.MMDevice MMDevice_FindCapture(string FriendlyName) {
            foreach (var Device in new NAudio.CoreAudioApi.MMDeviceEnumerator().EnumerateAudioEndPoints(NAudio.CoreAudioApi.DataFlow.Capture, NAudio.CoreAudioApi.DeviceState.Active)) {
                if (Device.FriendlyName.Equals(FriendlyName)) {
                    Console.WriteLine("CAudioIn: Capture device selected. [" + Device.FriendlyName + "]");
                    return Device;
                }
            }

            foreach (var Device in new NAudio.CoreAudioApi.MMDeviceEnumerator().EnumerateAudioEndPoints(NAudio.CoreAudioApi.DataFlow.Capture, NAudio.CoreAudioApi.DeviceState.Active)) {
                Console.WriteLine(Device.ID + "\t" + Device.FriendlyName + "\t" + Device.DeviceFriendlyName + "\t" + Device.DataFlow.ToString());
            }

            throw new Exception("CAudioIn: 指定されたCaptureデバイスがWASAPIで見つかりませんでした。 [" + FriendlyName + "]");
        }
    }
}
