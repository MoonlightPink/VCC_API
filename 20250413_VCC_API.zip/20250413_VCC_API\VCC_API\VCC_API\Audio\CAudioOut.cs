﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Quic;
using System.Text;
using System.Threading.Tasks;

namespace VCC_API {
    internal class CAudioOut {
        private CVBAN VBAN;

        private System.Threading.Tasks.Task ThreadTask;

        public class CHeartBeat {
            private const int Settings_BPM = 30;
            private const float Settings_Volume = 0.03f;

            public List<float> Source;
            public CHeartBeat() {
                Source = new List<float>();
                using (var rfs = new NAudio.Wave.WaveFileReader(@"C:\Users\morit\OneDrive\_VRChat\VCC_API_SE_HeartBeat_48kHz16bitsMono.wav")) {
                    while (rfs.Position < rfs.Length) {
                        var buf = new byte[2];
                        rfs.Read(buf);
                        Source.Add(BitConverter.ToInt16(buf) / 32768f);
                    }
                }
            }

            private int BPM = 0;
            private float Volume = 0.5f;

            public void SetParam(int _BPM, float _Volume) {
                lock (this) {
                    BPM = _BPM;
                    Volume = _Volume;
                }
            }

            public bool GetEnable() {
                return BPM != 0;
            }
            public void SetEnable(bool f) {
                if (f) {
                    SetParam(Settings_BPM, Settings_Volume);
                } else {
                    SetParam(0, 0f);
                }
            }

            private DateTime LastDT = DateTime.FromBinary(0);

            public bool ReqPlay() {
                lock (this) {
                    if (GetEnable()) {
                        var Interval = System.TimeSpan.FromSeconds((1d * 60) / BPM);
                        return (LastDT + Interval) < System.DateTime.Now;
                    } else {
                        return false;
                    }
                }
            }
            public void PlayWriteConsole() {
                Console.WriteLine("Play heart beat. BPM=" + BPM + ", Volume=" + Volume);
            }
            public void SetTo(List<float> Target) {
                lock (this) {
                    LastDT = System.DateTime.Now;
                    foreach (var smp in Source) {
                        Target.Add(smp * Volume);
                    }
                }
            }
        }
        public CHeartBeat HeartBeat = new CHeartBeat();

        public class CVolume {
            private float Level = 1f;
            public void SetLevel(float _Level) { lock (this) { Level = _Level; } }
            public float GetLevel() { lock (this) { return Level; } }
        }
        public CVolume Volume = new CVolume();

        public CAudioOut() {
            VBAN = new CVBAN(CAudio.Settings.VBAN.Addr, CAudio.Settings.VBAN.Port, CAudio.Settings.AudioOut.SampleRate, CAudio.Settings.VBAN.StreamName);

            ThreadTask = System.Threading.Tasks.Task.Run(ThreadExec);
        }

        private List<float> AudioBuf = new List<float>();

        private class CMixStream {
            public List<float> MicStream = new List<float>();
            public List<float> SpeakerStream = new List<float>();
        }
        private CMixStream MixStream = new CMixStream();

        private void GetMixStream() {
            try {
                var fn = "MixStream.f32";
                if (!System.IO.File.Exists(fn)) { return; }

                var gain = 0.5f;

                var MicStream = new List<float>();
                var SpeakerStream = new List<float>();

                using (var rfs = new System.IO.StreamReader(fn)) {
                    using (var br = new System.IO.BinaryReader(rfs.BaseStream, Encoding.UTF8, true)) {
                        for (var idx = 0; idx < br.BaseStream.Length / 8; idx++) {
                            MicStream.Add(br.ReadSingle() * gain);
                            SpeakerStream.Add(br.ReadSingle() * gain);
                        }
                    }
                }

                MixStream.SpeakerStream.Clear();

                lock (MixStream) {
                    MixStream.MicStream = MicStream;
                    MixStream.SpeakerStream = SpeakerStream;
                }

                Console.WriteLine("Mix stream loaded.");

                System.IO.File.Delete(fn);
            } catch (Exception ex) {
                Console.WriteLine("GetMixStream exception: " + ex.ToString());
            }
        }

        private void GetHeartBeat() {
            lock (MixStream) {
                if (MixStream.MicStream.Count != 0) { return; }
            }
            if (HeartBeat.ReqPlay()) {
                HeartBeat.PlayWriteConsole();
                lock (MixStream) {
                    HeartBeat.SetTo(MixStream.MicStream);
                }
            }
        }

        public void ThreadExec() {
            while (true) {
                try {
                    while (true) {
                        System.Threading.Thread.Sleep(100);

                        GetMixStream();
                        GetHeartBeat();
                    }
                } catch (Exception ex) { Console.WriteLine("CAudioOut: Thread exception: " + ex.Message + "\n" + ex.StackTrace); Environment.Exit(1); }
            }
        }

        private void ApplyRateStatus(CAudio.CAudioBlock AudioBlock) {
            lock (AudioBuf) {
                CAudio.RateStatus.SetRate(System.DateTime.Now - AudioBlock.SampleHeadDT);
                var VBAN_Setting_NetQuality = 512; // Optimal
                //var VBAN_Setting_NetQuality = 2048; // Medium
                //var VBAN_Setting_NetQuality = 4096; // Slow
                CAudio.RateStatus.AudioOut = System.TimeSpan.FromSeconds((double)VBAN_Setting_NetQuality / CAudio.Settings.AudioOut.SampleRate);
            }
        }

        public void SendSamples(CAudio.CAudioBlock AudioBlock) {
            if (AudioBlock.Samples.Length == 0) { return; }
            //Console.WriteLine(System.DateTime.Now.TimeOfDay.ToString() + "\tCAudioOut: SendSamples: AudioBlock.Samples.Length=" + AudioBlock.Samples.Length);

            ApplyRateStatus(AudioBlock);

            lock (MixStream) {
                if (1 <= MixStream.MicStream.Count) {
                    var cnt = (AudioBlock.Samples.Length < MixStream.MicStream.Count) ? AudioBlock.Samples.Length : MixStream.MicStream.Count;
                    for (var idx = 0; idx < cnt; idx++) {
                        AudioBlock.Samples[idx] += MixStream.MicStream[idx];
                    }
                    MixStream.MicStream.RemoveRange(0, cnt);
                }
            }

            var SendDT = AudioBlock.StartConvertDT + CAudio.Settings.AudioIn.GetChunkTS();

            VBAN.SendPacket(SendDT, AudioBlock.Samples, Volume.GetLevel());
        }
    }
}
